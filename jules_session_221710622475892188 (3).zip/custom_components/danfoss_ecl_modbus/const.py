"""Constants for the Danfoss ECL Modbus integration."""

DOMAIN = "danfoss_ecl_modbus"
